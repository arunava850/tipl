sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("my.tinybooksui.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);